EXPERIMENTAL SIMULATED-LOCATION MODEL
Observed county counts are real; within-county points are randomly allocated.
Outputs are conditional allocated customer impact, not physical outage probabilities.
No weather or canopy predictors were trained. Calendar/geography only.
Unzip preserving output/ object keys and model-ref.json. Use the matching
outage_model.experimental Python package and requirements-model.lock plus
requirements-experimental.txt. See EXPERIMENTAL_RANDOM_POINTS.md.
Dataset/source references in the manifest describe provenance but the large
training matrices/raw CSV are intentionally not included or needed for inference.
